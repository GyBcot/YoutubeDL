#!/usr/bin/env node

const path = require('path');
const cors = require('cors');
const chalk = require('chalk');
const express = require('express');
const downloadRouter = require('./routes/download.js');

const app = express();
const port = 3000;

app.enable('trust proxy');
app.set('json spaces', 2);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(cors());
app.use(express.urlencoded({ extended: true }));

app.use(express.json({
    verify: (req, res, buf) => {
        req.rawBody = buf.toString('utf8');
    }
}));

app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
    res.render('index', { page: 'home' });
});

app.use('/api/dl', downloadRouter);

app.use((req, res) => res.status(404).render('404', { page: '404' }));

app.listen(port, () => {
    console.log(chalk.green(`Server running on http://localhost:${port}`));
});

module.exports = app;
