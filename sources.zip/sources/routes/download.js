#!/usr/bin/env node

const axios = require('axios');
const express = require('express');

const router = express.Router();
const { getInfo, getDownloadUrl } = require('../lib/savetube');
const { verifyRequest, encryptResponse } = require('../lib/verify');

const err = (msg) => ({ success: false, message: msg });

const isYoutubeUrl = (url) =>
    /^(https?:\/\/)?(www\.|m\.|music\.)?(youtube\.com\/(watch|shorts|live|embed|v)(\/|\?)|youtu\.be\/)/i.test(String(url || '').trim());

const fileExt = (type) => type === 'audio' ? 'mp3' : 'mp4';

const safeFileName = (slug, quality, type) => {
    const base = String(slug || 'video')
        .replace(/[^a-zA-Z0-9._-]+/g, '-')
        .replace(/-+/g, '-')
        .replace(/^-|-$/g, '')
        .slice(0, 80) || 'video';
    return `${base}-${quality}.${fileExt(type)}`;
};

const parseDuration = (text) => {
    const parts = (text || '0:00').split(':').map(Number);
    if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
    if (parts.length === 2) return parts[0] * 60 + parts[1];
    return 0;
};

const searchYouTube = async (query) => {
    const { data } = await axios.post(
        'https://www.youtube.com/youtubei/v1/search?prettyPrint=false',
        {
            query,
            context: {
                client: {
                    clientName: 'WEB',
                    clientVersion: '2.20231121.08.00',
                    hl: 'id',
                    gl: 'ID'
                }
            }
        },
        {
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept-Language': 'id-ID,id;q=0.9'
            },
            timeout: 10000
        }
    );

    const sections = data?.contents?.twoColumnSearchResultsRenderer?.primaryContents?.sectionListRenderer?.contents || [];
    const videos = [];

    for (const section of sections) {
        for (const item of section?.itemSectionRenderer?.contents || []) {
            const v = item?.videoRenderer;
            if (!v?.videoId) continue;
            const durationText = v.lengthText?.simpleText || '0:00';
            videos.push({
                id: v.videoId,
                title: v.title?.runs?.[0]?.text || '',
                url: `https://www.youtube.com/watch?v=${v.videoId}`,
                thumbnail: `https://i.ytimg.com/vi/${v.videoId}/hqdefault.jpg`,
                duration: parseDuration(durationText),
                durationText,
                author: v.ownerText?.runs?.[0]?.text || '',
                views: parseInt((v.viewCountText?.simpleText || '').replace(/[^0-9]/g, '')) || 0
            });
            if (videos.length >= 20) break;
        }
        if (videos.length >= 20) break;
    }

    return videos;
};

router.post('/search', verifyRequest, async (req, res) => {
    try {
        const query = String(req.body?.query || '').trim();
        if (!query) return res.json(encryptResponse(err('Query pencarian wajib diisi.')));

        if (isYoutubeUrl(query)) {
            const info = await getInfo(query);
            return res.json(encryptResponse({ success: true, data: { type: 'direct', info } }));
        }

        const videos = await searchYouTube(query);
        res.json(encryptResponse({ success: true, data: { type: 'list', videos } }));
    } catch (e) {
        res.status(500).json(encryptResponse(err(e.message)));
    }
});

router.post('/info', verifyRequest, async (req, res) => {
    try {
        const url = String(req.body?.url || '').trim();
        if (!url) return res.json(encryptResponse(err('URL YouTube wajib diisi.')));
        if (!isYoutubeUrl(url)) return res.json(encryptResponse(err('URL tidak valid. Tempel link YouTube (youtube.com atau youtu.be).')));
        const info = await getInfo(url);
        res.json(encryptResponse({ success: true, data: info }));
    } catch (e) {
        res.status(500).json(encryptResponse(err(e.message)));
    }
});

router.post('/download', verifyRequest, async (req, res) => {
    try {
        const { key, downloadType, quality, titleSlug } = req.body || {};
        if (!key) return res.json(encryptResponse(err('Key video tidak ditemukan.')));
        if (downloadType !== 'video' && downloadType !== 'audio') return res.json(encryptResponse(err('Tipe download tidak valid.')));
        if (!quality) return res.json(encryptResponse(err('Kualitas wajib dipilih.')));
        const downloadUrl = await getDownloadUrl(key, downloadType, quality);
        res.json(encryptResponse({ success: true, data: { downloadUrl, filename: safeFileName(titleSlug, quality, downloadType) } }));
    } catch (e) {
        res.status(500).json(encryptResponse(err(e.message)));
    }
});

router.get('/file', async (req, res) => {
    try {
        const target = String(req.query.u || '');
        const name = String(req.query.n || 'video.mp4');
        const parsed = new URL(target);
        if (parsed.protocol !== 'https:' || !parsed.hostname.endsWith('.savetube.vip')) {
            return res.status(400).json(err('Host file tidak diizinkan.'));
        }
        const fileRes = await axios.get(target, { responseType: 'stream' });
        res.setHeader('Content-Type', fileRes.headers['content-type'] || 'application/octet-stream');
        res.setHeader('Content-Disposition', `attachment; filename="${name.replace(/"/g, '')}"`);
        if (fileRes.headers['content-length']) res.setHeader('Content-Length', fileRes.headers['content-length']);
        fileRes.data.pipe(res);
    } catch (e) {
        if (!res.headersSent) res.status(500).json(err(e.message));
    }
});

module.exports = router;
